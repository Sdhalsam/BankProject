package com.demo.service;

import java.sql.SQLException;
import java.util.List;

import com.demo.model.Account;

public interface AccountService {

	//should debit the given amount from the given accountNumber
	public Long withdraw(int amount,Long accountNumber) throws SQLException;

	//should credit the given amount from the given accountNumber
	public Long deposit(int amount,Long accountNumber) throws SQLException;

	//should insert/create a new account
	public void createAccount(Account account) throws SQLException;

	//should deactivate given account updating the isActive property to false
	public void deActivateAccount(Long accountNumber)throws SQLException;

	//should activate given account updating the isActive property to true
	public void activateAccount(Long accountNumber)throws SQLException;	

	//should perform DEBIT and CREDIT operations using the given inputs HINT: REFER account service
	public Long transfer(Long fromAccount,Long toAccount,int amount) throws SQLException;
}

package com.demo.repository;

import java.util.List;
import java.util.Map;

import com.demo.model.Account;


public interface AccountRepository {
		
	public Account findAccountByNumber(Long accountNUmber) ;
	
	public void save(Account account) ;
	
	public void update(Account account);
	
	//should deactivate the account
	public void deActivateAccount(Account account);
	
	//should activate the account
	public void activateAccount(Account account);

	
}

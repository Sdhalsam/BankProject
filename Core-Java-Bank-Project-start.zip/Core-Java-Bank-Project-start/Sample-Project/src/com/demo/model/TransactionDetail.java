package com.demo.model;

import java.util.Date;

public class TransactionDetail {

	private Long transactionId;
	private Account account;

	private Date transactionDate;
	private int amount;	
	private TransactionType txType;
	private int currentBalance;
	
	
	public int getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(int currentBalance) {
		this.currentBalance = currentBalance;
	}

	

	public TransactionDetail() {
		// TODO Auto-generated constructor stub
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	
	public TransactionDetail(Long transactionId, Account account, Date transactionDate, int amount,
			TransactionType txType, int currentBalance) {
		super();
		this.transactionId = transactionId;
		this.account = account;
		this.transactionDate = transactionDate;
		this.amount = amount;
		this.txType = txType;
		this.currentBalance = currentBalance;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}

	public TransactionType getTxType() {
		return txType;
	}

	public void setTxType(TransactionType txType) {
		this.txType = txType;
	}
	
	
}

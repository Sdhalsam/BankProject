package com.demo.model;

import java.util.Set;

public class Account {

	private Long accountNumber;
	private String name;
	private boolean isActive;

	private Set<Customer> customers;

	private int balance;

	public Account() {
		// TODO Auto-generated constructor stub
	}

	public void debit(int amount) {
		balance -= amount;
	}

	public void credit(int amount) {
		balance += amount;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	 

	public Account(Long accountNumber, String name, boolean isActive, Set<Customer> customers, int balance) {
		super();
		this.accountNumber = accountNumber;
		this.name = name;
		this.isActive = isActive;
		this.customers = customers;
		this.balance = balance;
	}

	public Set<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(Set<Customer> customers) {
		this.customers = customers;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
